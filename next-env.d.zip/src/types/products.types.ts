export type ProductItem = {
  id: string;
  title: string;
  thumbnail: string;
  photos: string[];
  price: number;
  acreage: number;
  address: string;
  totalBedrooms: number;
  totalToilets: number;
  description: string;
};
