__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/935b55440f09dcde.js",
  "static/chunks/turbopack-b72d928127716b0a.js"
])
