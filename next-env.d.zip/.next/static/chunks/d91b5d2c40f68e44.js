__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/935b55440f09dcde.js",
  "static/chunks/turbopack-20127efa27adaf4e.js"
])
